package hellocucumber;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Test {

	public static void main(String[] args) {
		/*
		 * ArrayList<String> price = new ArrayList<>(); price.add("£22.00 – £89.00");
		 * price.add("£25.00 £20.00"); price.add("£25.00 £19.00");
		 * price.add("£89.00 – £99.00");
		 */
		
		/*
		 * String s =
		 * "[£22.00 – £89.00, £25.00 £20.00, £25.00 £19.00, £89.00 – £99.00]"; String
		 * removeSpeci = s.replaceAll("([^0-9.\\s])", "");
		 * System.out.println("removeSpeci: "+removeSpeci); String[] values =
		 * removeSpeci.split(" ");
		 * 
		 * ArrayList<Double> dblit = new ArrayList<>(); for(int i=0; i<values.length;
		 * i++) { System.out.println(values[i]); if(values[i]!="") { double d =
		 * Double.parseDouble(values[i]); dblit.add(d); }
		 * 
		 * } System.out.println("dblit: "+dblit); double min = Collections.min(dblit);
		 * 
		 * System.out.println("min: "+min);
		 */
		
		String s = "£25.00 £19.00";
		String p = "19.0";
		if(s.contains(p)) {
			System.out.println("passed");
		}else {
			System.out.println("Failed");
		}
	}

}
