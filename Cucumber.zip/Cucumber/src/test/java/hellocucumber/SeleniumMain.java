package hellocucumber;


import static org.junit.Assert.assertFalse;
import static utility.CommonUtils.filePath;
import static utility.CommonUtils.locator;
import static utility.CommonUtils.retrieveColumnWiseData;
import static utility.CommonUtils.verifyText;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;


public class SeleniumMain extends SeleniumBase{	
	 
	 
	public void launchBrowser() throws IOException {		  
		  if(locator("browserName").equalsIgnoreCase("chrome")) {
		  System.setProperty("webdriver.chrome.driver", filePath("./Driver")+"/chromedriver.exe"); 
		  driver = new ChromeDriver();	
		  } 		  
		  else if(locator("browserName").equalsIgnoreCase("ie")) {
		  System.setProperty("webdriver.ie.driver", filePath("./Driver")+"/IEDriverServer.exe"); 
		  driver = new InternetExplorerDriver(); 		 
		  }
		
	}
	
	
	
	
	
	public void verifyHeader() throws IOException {
		String expectedvalue = "Admin area demo-1";
		String actualvalue = driver.findElement(By.xpath(locator("header"))).getText();
		verifyText(expectedvalue, actualvalue);
	}
	
	public void openTestDemo() throws IOException {
		driver.get(locator("URL")); 
		driver.manage().window().maximize(); 
	}
	
	public void addProductsToWishList(String products) throws IOException, InterruptedException {
		driver.findElement(By.xpath(locator("searchProductstxt"))).sendKeys(products);
		Thread.sleep(1000);
		driver.findElement(By.xpath(locator("searchProductBtn"))).click();
		Thread.sleep(2000);
		String actualProduct = driver.findElement(By.xpath(locator("productTitle"))).getText();
		verifyText(products, actualProduct);
		driver.findElement(By.xpath(locator("addToWishlistlink"))).click();
		Thread.sleep(3000);
		String actualConfirmation = driver.findElement(By.xpath(locator("productaddedtxt"))).getText();
		String expectedConfirmation = "Product added";
		verifyText(actualConfirmation.trim(), expectedConfirmation.trim());
		Thread.sleep(3000);
		driver.findElement(By.xpath(locator("shop"))).click();
		Thread.sleep(3000);
	}
	
	ArrayList<String> selectedProducts = new ArrayList<>();
	
	public void addProductsToWishList_new(io.cucumber.datatable.DataTable dataTable) throws Throwable {
		List<List<String>> products = dataTable.asLists(String.class);
		System.out.print("products: "+products.size());		
		for(List<String> p:products) {
			for(String val: p) {
				driver.findElement(By.xpath(locator("searchProductstxt"))).sendKeys(val);
				Thread.sleep(1000);
				driver.findElement(By.xpath(locator("searchProductBtn"))).click();
				Thread.sleep(2000);
				String actualProduct = driver.findElement(By.xpath(locator("productTitle"))).getText();
				verifyText(val, actualProduct);
				driver.findElement(By.xpath(locator("addToWishlistlink"))).click();
				Thread.sleep(3000);
				String actualConfirmation = driver.findElement(By.xpath(locator("productaddedtxt"))).getText();
				String expectedConfirmation = "Product added!";
				verifyText(actualConfirmation.trim(), expectedConfirmation.trim());
				Thread.sleep(3000);
				driver.findElement(By.xpath(locator("shop"))).click();
				Thread.sleep(3000);
				selectedProducts.add(val);
				
			}
		   }
		  System.out.println("selectedProducts: "+selectedProducts);
		}
	
	
	public void verifyWishlistItems() throws IOException {
		driver.findElement(By.xpath(locator("wishList"))).click();
	}
	
	
	public void verifySelectedProducts() throws IOException {
	ArrayList<String> wishlistProducts = retrieveColumnWiseData(driver, 2);
		Collections.sort(selectedProducts);
		Collections.sort(wishlistProducts);
		System.out.println("After Sort selectedProducts: "+selectedProducts);
		System.out.println("After Sort wishlistProducts: "+wishlistProducts);
		if(selectedProducts.equals(wishlistProducts)) {
			System.out.println("Test Passed matched wishlist products");
		}else {
			System.out.println("Test Failed Not matched wishlist products");
			assertFalse("wishlist issue", true);
		}
	}
		
	ArrayList<String> unicPrice = new ArrayList<>();
	ArrayList<Double> dblit = new ArrayList<>();
	String[] lowprice = new String[4];
	WebElement wishlistTable;
	List<WebElement> rows;
	public void selectedLowPriceProduct() throws IOException {		
		 wishlistTable = driver.findElement(By.xpath(locator("wishlistTable")));
		 rows = wishlistTable.findElements(By.tagName("tr"));
		//System.out.println("rows: "+rows.size());
		for(WebElement row:rows) {
			List<WebElement> cols = row.findElements(By.tagName("td"));
			//System.out.println("product Name 2 : "+cols.get(3).getText());
			unicPrice.add(cols.get(3).getText());			
		}	
		
		for(String val:unicPrice) {
			String removeSpeci = val.replaceAll("([^0-9.\\s])", "");
			//System.out.println("removeSpeci: "+removeSpeci);			
			
			String[] values = removeSpeci.split(" ");				
			int count =0;
			for(int i=0; i<values.length; i++) {
				//System.out.println("remove Space: "+values[i]);			
				if(values[i]!="") {
					double d = Double.parseDouble(values[i]);
					dblit.add(d+count);
					count = count++;
				}
				
			}		
					

		}
		//System.out.println("dblit: "+dblit);
	    double min = Collections.min(dblit);
	    String min_str = String.valueOf(min);
	
		System.out.println("min: "+min);
		
		wishlistTable = driver.findElement(By.xpath(locator("wishlistTable")));
		rows = wishlistTable.findElements(By.tagName("tr"));
		//System.out.println("rows: "+rows.size());
		for(WebElement row:rows) {
			List<WebElement> cols = row.findElements(By.tagName("td"));
			String unpri = cols.get(3).getText();
			System.out.println("unpri: "+unpri);
			if(unpri.contains("£"+min_str)) {
				String link = cols.get(5).getText();
				System.out.println("link: "+link);
				 cols.get(5).click();;
				driver.findElement(By.xpath("//*[@id=\"yith-wcwl-row-22\"]/td[6]/a"));
				break;
			}
		}		
		
	}
	
	
	
	

}
