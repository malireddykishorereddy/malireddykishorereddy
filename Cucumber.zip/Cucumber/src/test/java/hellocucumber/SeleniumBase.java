package hellocucumber;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumBase {  

   public static WebDriver driver;
  //public static ChromeDriver driver=null;
  
  
}
