package hellocucumber;

import static utility.CommonUtils.filePath;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features=".//Resources/MyShopping.feature",
 glue="steps",
 tags= "@Test",
 monochrome=true,
 plugin= {"pretty", "html:target/htmlreports"}
)
public class RunCucumberTest {
	
	@BeforeClass
	public static void cleanDirectory() {			
		try {
			System.out.println("Before Class");
			String sspath = filePath("./Screenshots");			
			File abs = new File(sspath);
			if(!abs.exists()) {
				abs.mkdirs();
				System.out.println("Screen shots folder created");
			}else {
				System.out.println("Screen shots folder alredy exists");
			}
			FileUtils.cleanDirectory(abs);
			System.out.println("Directory is empty");
		}catch (Exception e) {
			System.out.println("Error in Before Class");
		}
	}
	
	@AfterClass
	public static void closeDriver() {
		try {
			System.out.println("After Class");
			SeleniumBase objTest = new SeleniumBase();
			//objTest.driver.quit();
		}catch (Exception e) {
			System.out.println("Error while quitting the browser");
		}
		
	}
	
}
