package hellocucumber;

import static utility.CommonUtils.filePath;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class Hook {
	
	@Before
	public void setUp(Scenario scenario) {
		try {
			System.out.println("Before the Testing");
		}catch (Exception e) {
			System.out.println("Error in Before block");
		}
	}
	
	@After
	public void tearDown(Scenario scenario) {
		SeleniumBase testobject = new SeleniumBase();
		try {
			if(scenario.isFailed()) {
				TakesScreenshot failSS = (TakesScreenshot)testobject.driver;
				File testFail = failSS.getScreenshotAs(OutputType.FILE);
				String[] firstsplit = scenario.getId().split(".feature");
				System.out.println("firstsplit: "+firstsplit);
				String[] lastsplit = firstsplit[firstsplit.length-2].split("/");
				System.out.println("lastsplit: "+lastsplit);
				String scenarioName = lastsplit[lastsplit.length-1];
				String featureName = scenarioName.replaceAll("%20", " ");
				String ssDirectorypath = filePath("./Screenshots");
				FileUtils.copyFile(testFail, new File(ssDirectorypath+"/"+featureName+" "+scenario.getName()+".png")); //, false
				System.out.println("Screen Shot Taken");
				//testobject.driver.close();
			}
		}catch (Exception e) {
			System.out.println("Error in After block");
		}
	}
}
