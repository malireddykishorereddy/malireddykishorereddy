package utility;

import static org.junit.Assert.assertFalse;
import static utility.CommonUtils.locator;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CommonUtils {
	
	public static String filePath(String driverLoction) {
		File driverDirectroy = new File(driverLoction);
		String path = driverDirectroy.getAbsolutePath();
		return path;
	}
	
	public static String locator(String key) throws IOException {
		Properties properties = new Properties();
		FileInputStream fis = new FileInputStream("Page.properties");
		properties.load(fis);
		return properties.getProperty(key);
	}
	
	public static void verifyText(String expectedtxt, String actualtxt) {
		if(expectedtxt.equalsIgnoreCase(actualtxt)) {
			System.out.println("Test Passed expected text is: "+expectedtxt+ " and actual txt is: "+actualtxt);
		}else {
			System.out.println("Test Failed expected text is: "+expectedtxt+ " and actual txt is: "+actualtxt);
			assertFalse("verify text issue", true);
		}
	}
	
	public static ArrayList<String> retrieveColumnWiseData(WebDriver driver, int colNumber) throws IOException {
		ArrayList<String> wishlistProducts = new ArrayList<>();WebElement wishlistTable = driver.findElement(By.xpath(locator("wishlistTable")));
		List<WebElement> rows = wishlistTable.findElements(By.tagName("tr"));
		//System.out.println("rows: "+rows.size());
		for(WebElement row:rows) {
			List<WebElement> cols = row.findElements(By.tagName("td"));
			//System.out.println("product Name: "+cols.get(2).getText());
			wishlistProducts.add(cols.get(colNumber).getText());
		}		
		return wishlistProducts;
	}

}
