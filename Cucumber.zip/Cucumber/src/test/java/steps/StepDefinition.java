package steps;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;



import hellocucumber.SeleniumMain;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition {
	
	SeleniumMain testObject = new SeleniumMain();
	
	private ExtentReports report;
	ExtentSparkReporter sparkReporter;
	private ExtentTest test;
	public String timestamp = new SimpleDateFormat("yyyyMMddHHmmssSS").format(new Date());
	private String projectPath = System.getProperty("user.dir");
	
	// To initialize the report for the current scenario
	
	@Before
	public void createReport(Scenario scenario) {
		System.out.println("projectPath: "+projectPath);
		System.out.println("scenario: "+scenario.getName());
		report =  new ExtentReports();
		 sparkReporter = new ExtentSparkReporter(projectPath+"/target/extents.html"); //projectPath+"target/extentreports/extents.html"
		//report = new ExtentReports(projectPath+"/target/extentreports/consolidatedreport.html",true);
		//test.createcreateReport("Test: "+scenario.getName());
		//report.attachReporter(sparkReporter);
		test = report.createTest(scenario.getName());
		
		System.out.println("test name: "+test);
	}
	
	private ExtentTest createReport(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	// To end the writing of report for the current scenario
	
	  @After 
	  public void endTest(){ 
		  report.flush(); 
	  }
	 
	
	
	@Given("I launch browser")
	public void i_launch_browser() throws IOException {
		try {
			testObject.launchBrowser();
			test.log(Status.PASS, "Successfully opened browser");
		}catch (AssertionError error) {
			test.log(Status.FAIL, "NOT opened browser");
		}
		
	}

	
	@Then("I verify header name")
	public void i_verify_header_name() throws IOException {
		testObject.verifyHeader();
	}
	
	// Shopping 
	
	@When("I open testscriptdemo application")
	public void i_open_testscriptdemo_application() throws IOException {
		try {
			testObject.openTestDemo();
			test.log(Status.PASS, "Successfully opened Test Demo application");
		}catch (AssertionError error) {
			test.log(Status.FAIL, "Test Demo application open issue");
		}
	}
	
	@When("I seach my desired products and added to my wishlist")
	public void i_seach_my_desired_products_and_added_to_my_wishlist(DataTable dataTable) throws Throwable {
		try {
			testObject.addProductsToWishList_new(dataTable);
			test.log(Status.PASS, "Successfully added products to my wishlist");
		}catch (AssertionError error) {
			test.log(Status.FAIL, "Not Successfully added products to my wishlist");
		}
		
	}

	@When("I seach my desired {string} and added to my wishlist")
	public void i_seach_my_desired_and_added_to_my_wishlist(String products) throws IOException, InterruptedException {
		try {
			testObject.addProductsToWishList(products);
			test.log(Status.PASS, "Successfully added products to my wishlist: "+products);
		}catch (AssertionError error) {
			test.log(Status.FAIL, "Not Successfully added products to my wishlist: "+products);
		}
	}

	@When("I view my wish list table")
	public void i_view_my_wish_list_table() throws IOException {
		try {
			testObject.verifyWishlistItems();
			test.log(Status.PASS, "Successfully verified selected items count");
		}catch (AssertionError error) {
			test.log(Status.FAIL, "Select items count not displayed");
		}
	}

	@Then("I verify four selectred items in my wishlist")
	public void i_verify_four_selectred_items_in_my_wishlist() throws IOException {
		try {
			testObject.verifySelectedProducts();
			test.log(Status.PASS, "Successfully verified selected products displayed in the wishlist");
		}catch (AssertionError error) {
			test.log(Status.FAIL, "NOT displayed Selected products in the wishlist");
		}
		
	}

	@When("I search for lowest price product")
	public void i_search_for_lowest_price_product() throws IOException {
		try {
			testObject.selectedLowPriceProduct();
			test.log(Status.PASS, "Successfully selected low proce product");
		}catch (AssertionError error) {
			test.log(Status.FAIL, "NOT Successfully selected low proce product");
		}
	}

	@When("I add lowest price item to my cart")
	public void i_add_lowest_price_item_to_my_cart() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("I verify item available in my cart")
	public void i_verify_item_available_in_my_cart() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
	
	
	
	
	
}
